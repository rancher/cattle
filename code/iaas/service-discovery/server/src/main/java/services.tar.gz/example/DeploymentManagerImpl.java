package example;

import com.google.common.util.concurrent.ListenableFuture;
import io.cattle.platform.async.utils.AsyncUtils;
import io.cattle.platform.core.model.Instance;
import io.cattle.platform.core.model.Service;
import io.cattle.platform.lock.LockCallbackNoReturn;
import io.cattle.platform.lock.LockManager;
import io.cattle.platform.lock.definition.LockDefinition;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by darren on 5/8/15.
 */
public class DeploymentManagerImpl implements DeploymentManager {

    @Inject
    LockManager lockManager;
    @Inject
    DeploymentUnitFactory deploymentUnitFactory;

    @Override
    public void activate(Service service) {
        final List<Service> services = collectServices(service);
        final Map<String, List<Instance>> instances = collectionInstances(services);

        lockManager.lock(createLock(services), new LockCallbackNoReturn() {
            @Override
            public void doWithLockNoResult() {
               runWithLock(services, instances);
            }
        })
    }

    protected List<Service> collectServices(Service service) {
        /*
        Find all sidekick services.  Just look at sidekick, not volumes-from or other things
         */
        return null;
    }

    protected LockDefinition createLock(List<Service> services) {
        /*
         Create a MultiLockDefinition that is a composite of locks for all services
         */
        return null;
    }


    protected Map<String, List<Instance>> collectionInstances(List<Service> services) {
        /*
         find all containers related to the services through the serviceexposemaps.  Then group all the containers
         by the label 'io.rancher.deployment.unit'.  When containers are deployed through service discovery that
         label will be placed on them.  More about that later...

         If no 'io.rancher.deployment.unit' label is found on the container, generate a random UUID for the value
         and use that
          */

        /*
         returns a map where the key is the value of 'io.rancher.deployment.unit' and the value is the containers
         associated to that value.
         */
        return null;
    }

    protected void runWithLock(List<Service> services, Map<String, List<Instance>> instances) {
        List<DeploymentUnit> units = new ArrayList<>();

        for (List<Instance> deploymentInstances : instances.values()) {
            DeploymentUnit unit = deploymentUnitFactory.createDeploymentUnit(services, deploymentInstances);
            units.add(unit);
        }

        units = deleteBadUnits(units);
        units = matchScale(services, units);

        List<ListenableFuture<?>> futures = startUnits(units);
        for (ListenableFuture<?> future : futures) {
            /* configurable setting */
            future.get(15, TimeUnit.SECONDS);
        }

        cleanup(units);
    }

    protected void cleanup(List<DeploymentUnit> units) {
        for (DeploymentUnit unit : units) {
            unit.cleanup();
        }
    }

    protected List<ListenableFuture<?>> startUnits(List<DeploymentUnit> units) {
        List<ListenableFuture<?>> result = new ArrayList<>(units.size());

        for (DeploymentUnit unit : units) {
            result.add(unit.start());
        }

        return result;
    }

    protected List<DeploymentUnit> deleteBadUnits(List<DeploymentUnit> units) {
        List<DeploymentUnit> result = new ArrayList<>(units.size());

        for (DeploymentUnit unit : units) {
            if (unit.isError()) {
                unit.remove();
            } else {
                result.add(unit);
            }
        }

        return result;
    }

    protected List<DeploymentUnit> matchScale(List<Service> services, List<DeploymentUnit> units) {
        /*
        If there are too many units, call unit.remove() and delete the excess.
        If there are not enough units, create new empty deployment units by call the factory
        and passing in the services and an empty list for instances.

        NOTE: We don't actually start services here
         */

        return null;
    }


}
