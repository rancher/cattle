package example;

import io.cattle.platform.core.model.Service;

/**
 * Created by darren on 5/8/15.
 */
public interface DeploymentManager {

    void activate(Service service);

}
