package example;

/**
 * Created by darren on 5/8/15.
 */
public class LoadBalancerDeploymentUnitImpl implements DeploymentUnit {
}
