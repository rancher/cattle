package example;

import com.google.common.util.concurrent.ListenableFuture;

/**
 * Created by darren on 5/8/15.
 */
public interface DeploymentUnit {
    boolean isError();

    void remove();

    ListenableFuture<?> start();

    void cleanup();
}
