package example;

import io.cattle.platform.core.model.Instance;
import io.cattle.platform.core.model.Service;

import java.util.List;

/**
 * Created by darren on 5/8/15.
 */
public class DeploymentUnitFactoryImpl implements DeploymentUnitFactory {
    @Override
    public DeploymentUnit createDeploymentUnit(String id, List<Service> service, List<Instance> containers) {
        /*
        if load balancer service return LoadBalancerDeploymentUnitImpl
        if not the CompositeServiceDeploymentUnitImpl.  The composite impl will work for just 1 container also.
        Doesn't have to be multiple
         */
        return null;
    }
}
