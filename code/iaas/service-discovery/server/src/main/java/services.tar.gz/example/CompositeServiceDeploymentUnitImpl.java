package example;

import com.google.common.util.concurrent.ListenableFuture;
import io.cattle.platform.core.model.Instance;
import io.cattle.platform.core.model.Service;

import java.util.List;

/**
 * Created by darren on 5/8/15.
 */
public class CompositeServiceDeploymentUnitImpl implements DeploymentUnit {

    String id;
    List<Service> services;
    List<Instance> instances;

    @Override
    public boolean isError() {
        /*
        This should check for instances with an error transitioning state
         */
        return false;
    }

    @Override
    public void remove() {
        /*
        Delete all instances.  This should be non-blocking (don't wait)
         */
    }

    @Override
    public ListenableFuture<?> start() {
        /*
        Start the services.  You should start the instances in the correct order depending on the volumes from.
        Attempt to start things in parallel, but if not possible (like volumes-from) then start each service
        sequentially.

        If there are three services but only two containers, create the third.

        If one of the containers service health is bad, then create another one (but don't delete the existing).

        When containers are launched put the label 'io.rancher.deployment.unit=this.id' on each one.  This way
        we can reference a set of containers later.
         */

        /*
        return a listenablefuture.  Kind of a pain...
         */
    }

    @Override
    public void cleanup() {
        /*
        Delete any containers that have a bad service health.  Do this non-blocking.
         */
    }
}
