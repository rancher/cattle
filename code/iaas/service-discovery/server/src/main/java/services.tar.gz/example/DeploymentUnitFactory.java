package example;

import io.cattle.platform.core.model.Instance;
import io.cattle.platform.core.model.Service;

import java.util.List;

/**
 * Created by darren on 5/8/15.
 */
public interface DeploymentUnitFactory {

    DeploymentUnit createDeploymentUnit(String id, List<Service> service, List<Instance> containers);

}
