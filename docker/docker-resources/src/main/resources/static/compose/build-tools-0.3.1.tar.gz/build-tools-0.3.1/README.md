# build-tools
Scripts used for builds with in Rancher

## Contact
For bugs, questions, comments, corrections, suggestions, etc., open an issue in
 [rancher/rancher](//github.com/rancher/rancher/issues) with a title starting with `[build-tools] `.

Or just [click here](//github.com/rancher/rancher/issues/new?title=%5Bbuild-tools%5D%20) to create a new issue.
