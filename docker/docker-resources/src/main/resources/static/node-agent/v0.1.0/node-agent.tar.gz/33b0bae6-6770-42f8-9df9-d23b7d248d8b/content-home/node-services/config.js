module.exports = {
    'token' : '${instance.token}'
}
